import torch
import torch.nn.functional as F  # torch.tanh
import torch.nn as nn
from torch.autograd import Variable
import scipy.io as sio
from utils.metric import compress, calculate_top_map
import utils.datasets_nus as datasets_nus
from utils.models import ImgNet, TxtNet, Autoencoder, Autoencoder1, domain_classifier_I, domain_classifier_T
import time
import os
from utils.utils import *
import utils.ramps as ramps
import logging
from models import *
import argparse
import numpy as np

parser = argparse.ArgumentParser(description="ADSH demo")
parser.add_argument('--bits', default='32', type=str,help='binary code length (default: 8,12,16,24,32,48,64,96,128)')
parser.add_argument('--eps-list', default='0.1', type=str,help='binary code length (default: 0.1,0.2)')
parser.add_argument('--gpu', default='1', type=str,help='selected gpu (default: 1)')
parser.add_argument('--batch-size', default=32, type=int, help='batch size (default: 64)')
parser.add_argument('--BETA', default=0.9, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--NUM-EPOCH', default=40, type=int, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--LR-IMG', default=0.001, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--LR-TXT', default=0.01, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--alpha', default=0.8, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--MOMENTUM', default=0.9, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--WEIGHT-DECAY', default=5e-4, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--ema-decay', default=0.999, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--consistency', default=100.0, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--consistency-rampup', default=30, type=int, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--NUM-WORKERS', default=4, type=int, help='number of epochs (default: 3)')
parser.add_argument('--LAMBDA1', default=0.1, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--LAMBDA2', default=0.1, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--EVAL', default= False, type=bool,help='selected gpu (default: 1)')
parser.add_argument('--EPOCH-INTERVAL', default=2, type=int, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--EVAL-INTERVAL', default=20, type=int, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('--MU', default=1.5, type=float, help='hyper-parameter: learning rate (default: 10**-3)')
parser.add_argument('-max-norm', type=float, default=3.0, help='l2 constraint of parameters [default: 3.0]')
parser.add_argument('-embed-dim', type=int, default=128, help='number of embedding dimension [default: 128]')
parser.add_argument('-kernel-num', type=int, default=128, help='number of each kind of kernel')
parser.add_argument('-kernel-sizes', type=str, default='3,4,5', help='comma-separated kernel size to use for convolution')
parser.add_argument('-vocab-size', type=int, default=1387, help='number of each kind of kernel')

class Session:
    def __init__(self):

        os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
        # torch.manual_seed(0)
        # torch.cuda.manual_seed(0)

        self.train_dataset = datasets_nus.NUSWIDE(train=True, transform=datasets_nus.nus_train_transform)
        self.test_dataset = datasets_nus.NUSWIDE(train=False, database=False, transform=datasets_nus.nus_test_transform)
        self.database_dataset = datasets_nus.NUSWIDE(train=False, database=True, transform=datasets_nus.nus_test_transform)
        # Data Loader (Input Pipeline)
        self.train_loader = torch.utils.data.DataLoader(dataset=self.train_dataset,
                                                        batch_size=args.batch_size,
                                                        shuffle=True,
                                                        num_workers=args.NUM_WORKERS,
                                                        drop_last=True)

        self.test_loader = torch.utils.data.DataLoader(dataset=self.test_dataset,
                                                       batch_size=args.batch_size,
                                                       shuffle=False,
                                                       num_workers=args.NUM_WORKERS)

        self.database_loader = torch.utils.data.DataLoader(dataset=self.database_dataset,
                                                           batch_size=args.batch_size,
                                                           shuffle=False,
                                                           num_workers=args.NUM_WORKERS)

        self.best_it = 0
        self.best_ti = 0

    def define_model(self, coed_length):

        self.CodeNet_N = Autoencoder1()
        self.CodeNet_I = ImgNet(code_len=coed_length)
        self.FeatNet_I = ImgNet(code_len=coed_length)

        self.txt_feat_len = datasets_nus.txt_feat_len
        self.CodeNet_T = TxtNet(code_len=coed_length, txt_feat_len=self.txt_feat_len)
        self.Clf_I = domain_classifier_I()
        self.Clf_T = domain_classifier_T( txt_feat_len=self.txt_feat_len)

        self.opt_I = torch.optim.SGD(self.CodeNet_I.parameters(), lr=args.LR_IMG, momentum=args.MOMENTUM, weight_decay=args.WEIGHT_DECAY)
        self.opt_T = torch.optim.SGD(self.CodeNet_T.parameters(), lr=args.LR_TXT, momentum=args.MOMENTUM, weight_decay=args.WEIGHT_DECAY)
        self.opt_Clf_I = torch.optim.SGD(self.Clf_I.parameters(), lr=args.LR_IMG, momentum=args.MOMENTUM, weight_decay=args.WEIGHT_DECAY)
        self.opt_Clf_T = torch.optim.SGD(self.CodeNet_T.parameters(), lr=args.LR_TXT, momentum=args.MOMENTUM, weight_decay=args.WEIGHT_DECAY)
        self.opt_N = torch.optim.Adam(self.CodeNet_N .parameters(), lr=args.LR_IMG)

        self.loss_domain = torch.nn.NLLLoss().cuda()

    def train(self, epoch, eps):
        self.CodeNet_N.cuda().train()
        self.CodeNet_I.cuda().train()
        self.FeatNet_I.cuda().eval()
        self.CodeNet_T.cuda().train()

        self.Clf_I.cuda().train()
        self.Clf_T.cuda().train()

        self.CodeNet_I.set_alpha(epoch)
        self.CodeNet_T.set_alpha(epoch)
        i = 0
        len_dataloader = len(self.train_loader)
        for idx, (img, F_T, labels, _) in enumerate(self.train_loader):
            p = float(idx + epoch * len_dataloader) / (args.NUM_EPOCH * len_dataloader)
            alpha = 2. / (1. + np.exp(-10 * p)) - 1
            alpha = float(alpha)
            i = i + 1

            # alpha =1.0

            img = Variable(img.cuda())
            F_T = Variable(torch.FloatTensor(F_T.numpy()).cuda())

            batch_size_ = img.size(0)
            # define domain label
            domain_label_1 = torch.zeros(batch_size_)
            domain_label_1 = domain_label_1.long().cuda()
            self.domain_label_1 = Variable(domain_label_1)

            domain_label_2 = torch.ones(batch_size_)
            domain_label_2 = domain_label_2.long().cuda()
            self.domain_label_2 = Variable(domain_label_2)

            # ---- noise image ----------------
            x, atkdata = self.CodeNet_N(img, alpha, eps)

            F_I, _, _ = self.FeatNet_I(img)
            _, _, code_I = self.CodeNet_I(img)
            _, _, code_T = self.CodeNet_T(F_T)
            _, _, code_NI = self.CodeNet_I(atkdata)

            C_I, _ = self.Clf_I(img)
            N_I, _ = self.Clf_I(atkdata)
            C_T, _ = self.Clf_T(F_T)

            # construct similarity matrix
            S = con_sim(F_I, F_T, self.txt_feat_len)

            B_I = F.normalize(code_I)
            B_T = F.normalize(code_T)
            B_NI = F.normalize(code_NI)

            BI_BI = B_I.mm(B_I.t())
            BT_BT = B_T.mm(B_T.t())
            BI_BT = B_I.mm(B_T.t())
            BN_BI1 = (B_I).mm(B_NI.t())
            BN_BT = (B_T).mm(B_NI.t())

            self.opt_I.zero_grad()
            self.opt_T.zero_grad()
            self.opt_N.zero_grad()
            self.opt_Clf_I.zero_grad()
            self.opt_Clf_T.zero_grad()

            loss1 = F.mse_loss(BI_BT, S) + F.mse_loss(B_I, B_T)
            loss2 = F.mse_loss(BT_BT, S) + F.mse_loss(BI_BI, S)
            loss3 = F.mse_loss(BN_BT, S) + F.mse_loss(BN_BI1, S)
            loss5 = F.mse_loss(B_NI, B_T) + F.mse_loss(B_I, B_NI)
            loss6 = self.loss_domain(N_I, self.domain_label_1) + self.loss_domain(C_I, self.domain_label_1)

            loss = (0.01 * loss1 + 0.01 * loss2 + 0.01 * loss3) + 1 * loss5 + 1 * loss6
            loss.backward()

            self.opt_I.step()
            self.opt_T.step()
            self.opt_N.step()
            self.opt_Clf_I.step()
            self.opt_Clf_T.step()

            if (idx + 1) % (len(self.train_dataset) // args.batch_size / args.EPOCH_INTERVAL) == 0:
                logger.info('Epoch [%d/%d], Iter [%d/%d] Loss1: %.4f'
                            % (epoch + 1, args.NUM_EPOCH1, idx + 1, len(self.train_dataset) // args.batch_size,
                                loss.item()))

    def train2(self, epoch, eps):

        self.CodeNet_N.cuda().eval()
        self.CodeNet_I.cuda().train()
        self.FeatNet_I.cuda().eval()
        self.CodeNet_T.cuda().train()

        self.Clf_I.cuda().train()
        self.Clf_T.cuda().train()

        self.CodeNet_I.set_alpha(epoch)
        self.CodeNet_T.set_alpha(epoch)
        i = 0
        len_dataloader = len(self.train_loader)
        for idx, (img, F_T, labels, _) in enumerate(self.train_loader):
            p = float(idx + epoch * len_dataloader) / (args.NUM_EPOCH * len_dataloader)
            alpha = 2. / (1. + np.exp(-10 * p)) - 1
            alpha = float(alpha)
            i = i + 1

            img = Variable(img.cuda())
            F_T = Variable(torch.FloatTensor(F_T.numpy()).cuda())

            batch_size_ = img.size(0)
            # define domain label
            domain_label_1 = torch.zeros(batch_size_)
            domain_label_1 = domain_label_1.long().cuda()
            self.domain_label_1 = Variable(domain_label_1)

            domain_label_2 = torch.ones(batch_size_)
            domain_label_2 = domain_label_2.long().cuda()
            self.domain_label_2 = Variable(domain_label_2)

            # ---- noise image ----------------
            with torch.no_grad():
                x, atkdata = self.CodeNet_N(img, alpha, eps)

            F_I, _, _ = self.FeatNet_I(img)
            _, _, code_I = self.CodeNet_I(img)
            _, _, code_T = self.CodeNet_T(F_T)
            _, _, code_NI = self.CodeNet_I(atkdata)

            C_I, _ = self.Clf_I(img)
            N_I, _ = self.Clf_I(atkdata)
            C_T, _ = self.Clf_T(F_T)

            # construct similarity matrix
            S = con_sim(F_I, F_T, self.txt_feat_len)

            B_I = F.normalize(code_I)
            B_T = F.normalize(code_T)
            B_NI = F.normalize(code_NI)

            BI_BI = B_I.mm(B_I.t())
            BT_BT = B_T.mm(B_T.t())
            BI_BT = B_I.mm(B_T.t())
            BN_BI1 = (B_I).mm(B_NI.t())
            BN_BT = (B_T).mm(B_NI.t())

            self.opt_I.zero_grad()
            self.opt_T.zero_grad()
            self.opt_Clf_I.zero_grad()
            self.opt_Clf_T.zero_grad()

            loss1 = F.mse_loss(BI_BT, S) + F.mse_loss(B_I, B_T)
            loss2 = F.mse_loss(BT_BT, S) + F.mse_loss(BI_BI, S)
            loss3 = F.mse_loss(BN_BT, S) + F.mse_loss(BN_BI1, S)
            loss5 = F.mse_loss(B_NI, B_T) + F.mse_loss(B_I, B_NI)
            loss6 = self.loss_domain(N_I, self.domain_label_1) + self.loss_domain(C_I, self.domain_label_1)

            loss = (1 * loss1 + 1 * loss2 + 1 * loss3) + 1 * loss5 + 1 * loss6
            loss.backward()

            self.opt_I.step()
            self.opt_T.step()
            self.opt_Clf_I.step()
            self.opt_Clf_T.step()

            if (idx + 1) % (len(self.train_dataset) // args.batch_size / args.EPOCH_INTERVAL) == 0:
                logger.info('Epoch [%d/%d], Iter [%d/%d] Loss1: %.4f'
                            % (epoch + 1, args.NUM_EPOCH1, idx + 1, len(self.train_dataset) // args.batch_size,
                                loss.item()))

    def eval(self, epoch, eps, bit):
        self.logger.info('--------------------Evaluation: Calculate top MAP-------------------')

        # Change model to 'eval' mode (BN uses moving mean/var).
        self.CodeNet_I.eval().cuda()
        self.CodeNet_T.eval().cuda()
        self.Clf_I.eval().cuda()
        self.Clf_T.eval().cuda()
        self.CodeNet_N.eval().cuda()

        path = os.path.join(logdir, str(args.CODE_LEN) + 'bits-Inoise-record.pkl')
        torch.save(self.CodeNet_N.state_dict(), path)

        re_BI, re_BT, re_L, re_BNI, qu_BI, qu_BT, qu_L, qu_BN, correct1, correct2, correct3, correct_1, correct_2, correct_3 \
                = compress(self.database_loader, self.test_loader, self.CodeNet_I, self.CodeNet_T, self.CodeNet_N,
                           self.Clf_I, self.Clf_T, self.database_dataset, self.test_dataset, eps)

        sio.savemat( '/home/pengfei/PycharmProjects/hash2/PIP_demo/nus/result/pip/' + str(eps) + '/' + str(
                    bit) + '/' + 'code.mat', {
                    're_BNI': re_BNI,
                    're_BI': re_BI,
                    're_BT': re_BT,
                    're_L': re_L,
                    'qu_BI': qu_BI,
                    'qu_BT': qu_BT,
                    'qu_BN': qu_BN,
                    'qu_L': qu_L})

        MAP_I2T = calculate_top_map(qu_B=qu_BI, re_B=re_BT, qu_L=qu_L, re_L=re_L, topk=50)
        MAP_I2I = calculate_top_map(qu_B=qu_BI, re_B=re_BI, qu_L=qu_L, re_L=re_L, topk=50)
        MAP_I2NI = calculate_top_map(qu_B=qu_BI, re_B=re_BNI, qu_L=qu_L, re_L=re_L, topk=50)

        MAP_NI2T = calculate_top_map(qu_B=qu_BN, re_B=re_BT, qu_L=qu_L, re_L=re_L, topk=50)
        MAP_NI2I = calculate_top_map(qu_B=qu_BN, re_B=re_BI, qu_L=qu_L, re_L=re_L, topk=50)
        MAP_T2I1 = calculate_top_map(qu_B=qu_BN, re_B=re_BNI, qu_L=qu_L, re_L=re_L, topk=50)

        MAP_T2I = calculate_top_map(qu_B=qu_BT, re_B=re_BI, qu_L=qu_L, re_L=re_L, topk=50)
        MAP_T2NI = calculate_top_map(qu_B=qu_BT, re_B=re_BNI, qu_L=qu_L, re_L=re_L, topk=50)
        MAP_T2T = calculate_top_map(qu_B=qu_BT, re_B=re_BT, qu_L=qu_L, re_L=re_L, topk=50)

        logger.info('MAP of Image to Text: %.3f, MAP of Image to Image: %.3f, MAP of Image to Noise Image: %.3f' % (
        MAP_I2T, MAP_I2I, MAP_I2NI))
        logger.info(
            'MAP of Noise Image to Text: %.3f, MAP of Noise Image to Image: %.3f, MAP of Noise Image to Noise Image: %.3f' % (
            MAP_NI2T, MAP_NI2I, MAP_T2I1))
        logger.info('MAP of Text to Image: %.3f, MAP of Text to Noise Image: %.3f, MAP of Text to Text: %.3f' % (
        MAP_T2I, MAP_T2NI, MAP_T2T))
        logger.info('label accuracy of database clean Image: %.3f, clean Text: %.3f, Noise Image: %.3f' % (
        correct1, correct2, correct3))
        logger.info('label accuracy of query clean Image: %.3f, clean Text: %.3f, Noise Image: %.3f' % (
        correct_1, correct_2, correct_3))
        logger.info('--------------------------------------------------------------------')

def con_sim(F_I, F_T, txt_feat_len):
    # for F_I
    F_I = F.normalize(F_I)
    S_I = F_I.mm(F_I.t())

    G_I = F_I.detach().clone()
    D_I = F_I.detach().clone()
    G_I[G_I > 0] = 1
    D_I[D_I == 0] = -1
    D_I[D_I > 0] = 0
    D_I1 = D_I.mm(D_I.t())
    G_I1 = G_I.mm(G_I.t())

    E_I1 = 4096 - (G_I1 + D_I1)
    F_I1 = (2 * (G_I1)) / (G_I1 + E_I1 + 0.1)
    S_I = S_I + (F_I1)
    S_I = S_I * 2 - 1

    # for F_T
    F_T = F.normalize(F_T)
    S_T = F_T.mm(F_T.t())

    G_T = F_T.detach().clone()
    D_T = F_T.detach().clone()
    # --------------------------------------------------#nus # mir
    G_T[G_T > 0] = 1
    G_T[G_T <= 0] = 0
    D_T[D_T == 0] = -1
    D_T[D_T > 0] = 0
    # --------------------------------------------------
    G_T1 = G_T.mm(G_T.t())
    D_T1 = D_T.mm(D_T.t())
    E_T1 = txt_feat_len - (G_T1 + D_T1)  # 10, 1386, 1000
    # ----------------------------------------------------------------#nus # mir
    F_T1 = (2 * abs(G_T1)) / (G_T1 + E_T1 + 0.01)  # 2-nus mir #1 wiki
    S_T = S_T + (F_T1)
    S_T = S_T * 2 - 1

    S_tilde = args.BETA * S_I + (1 - args.BETA) * S_T
    S = S_tilde

    return S

def get_current_consistency_weight(epoch):
    return args.consistency * ramps.sigmoid_rampup(epoch, args.consistency_rampup)

def update_ema_variables(model, ema_model, alpha, global_step):
    # Use the true average until the exponential average is more correct
    alpha = min(1 - 1 / (global_step + 1), alpha)
    for ema_param, param in zip(ema_model.parameters(), model.parameters()):
        ema_param.data.mul_(alpha).add_(1 - alpha, param.data)

def gaussian_kernel_matrix(dist, S1, S2):
    k1 = 1 / (torch.sum(S1, 1) + 0.01)
    k2 = 1 / (torch.sum(S2, 1) + 0.01)


    dist1 = dist * S1
    dist2 = dist * S2

    dist1 = torch.sum(dist1, 0)
    dist2 = torch.sum(dist2, 0)

    return dist1 * k1, dist2 * k2

def pairwise_distance(x, y):
    if not len(x.shape) == len(y.shape) == 2:
        raise ValueError('Both inputs should be matrices.')

    if x.shape[1] != y.shape[1]:
        raise ValueError('The number of features should be the same.')

    x = x.view(x.shape[0], x.shape[1], 1)
    y = torch.transpose(y, 0, 1)
    output = torch.norm(x - y, p=2, dim=1)
    output = torch.transpose(output, 0, 1)

    return output

def mkdir_multi(path):
    # 判断路径是否存在
    isExists = os.path.exists(path)

    if not isExists:
        # 如果不存在，则创建目录（多层）
        os.makedirs(path)
        print('successfully creat path！')
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print('path already exists！')
        return False

def _logging():
    global logger
    # logfile = os.path.join(logdir, 'log.log')
    logfile = os.path.join(logdir, 'log.log')
    logger = logging.getLogger('')
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(logfile)
    fh.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    _format = logging.Formatter("%(name)-4s: %(levelname)-4s: %(message)s")
    fh.setFormatter(_format)
    ch.setFormatter(_format)

    logger.addHandler(fh)
    logger.addHandler(ch)
    return


def main():
    global logdir, args

    args = parser.parse_args()

    sess = Session()

    bits = [int(bit) for bit in args.bits.split(',')]
    epss = [float(eps) for eps in args.eps_list.split(',')]
    for bit in bits:
        for eps in epss:
            logdir = '/home/pengfei/PycharmProjects/hash2/PIP_demo/nus/result/pip/' + str(args.eps) + '/' + str(bit) + '/'
            mkdir_multi(logdir)
            _logging()

            if args.EVAL == True:
                sess.load_checkpoints()
            else:
                logger.info('--------------------------Construct Models--------------------------')
                sess.define_model(bit)

                logger.info('--------------------------Adversarial Training--------------------------')
                for epoch in range(args.NUM_EPOCH):
                    # train the Model
                    iter_time1 = time.time()
                    sess.train(epoch, args)
                    iter_time1 = time.time() - iter_time1
                    logger.info('[pre_train time: %.4f]', iter_time1)
                    if (epoch + 1) % args.EVAL_INTERVAL == 0:
                        iter_time1_1 = time.time()
                        sess.eval(epoch, bit)
                        iter_time1_1 = time.time() - iter_time1_1
                        logger.info('[pre_train eval2 time: %.4f]', iter_time1_1)

                logger.info('--------------------------Experience Replay--------------------------')

                for epoch in range(args.NUM_EPOCH):
                    # train the Model
                    iter_time0 = time.time()
                    sess.train2(epoch, args)
                    iter_time0 = time.time() - iter_time0
                    logger.info('[pre_train time: %.4f]', iter_time0)
                    if (epoch + 1) % args.EVAL_INTERVAL == 0:
                        iter_time0_1 = time.time()
                        sess.eval(epoch, bit)
                        iter_time0_1 = time.time() - iter_time0_1
                        logger.info('[pre_train1 eval time: %.4f]', iter_time0_1)


if __name__=="__main__":
    main()